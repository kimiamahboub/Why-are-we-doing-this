self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c72eab4f8d0e5bf9ea4b4caacb94c3b1",
    "url": "/index.html"
  },
  {
    "revision": "8c7b5e665eea0ed2d93c",
    "url": "/static/css/main.1de25318.chunk.css"
  },
  {
    "revision": "cc5b60f530ec9ef2959d",
    "url": "/static/js/2.3dd64d21.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/2.3dd64d21.chunk.js.LICENSE.txt"
  },
  {
    "revision": "8c7b5e665eea0ed2d93c",
    "url": "/static/js/main.7e490b78.chunk.js"
  },
  {
    "revision": "415e9bcf6c081ea50565",
    "url": "/static/js/runtime-main.f8c5b4be.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/static/media/logo.5d5d9eef.svg"
  }
]);